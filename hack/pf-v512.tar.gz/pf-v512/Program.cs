﻿using System;
using System.Runtime.CompilerServices;

using System.Runtime.Intrinsics;
using System.Runtime.Intrinsics.X86;

namespace issues
{
    class Program
    {

        [MethodImpl(MethodImplOptions.NoInlining)]
				static Vector128<Int32> Add128(Int32 v1val, Int32 v2val)
				{
          Vector128<Int32> v1 = Vector128.Create(v1val);
          Vector128<Int32> v2 = Vector128.Create(v2val);
          Vector128<Int32> v3 = Avx.Add(v1, v2);
          return v3;
			  }

        [MethodImpl(MethodImplOptions.NoInlining)]
				static Vector128<float> Add128F(float v1val, float v2val)
				{
          Vector128<float> v1 = Vector128.Create(v1val);
          Vector128<float> v2 = Vector128.Create(v2val);
          Vector128<float> v3 = Avx.Add(v1, v2);
          return v3;
			  } 


        [MethodImpl(MethodImplOptions.NoInlining)]
				static Vector512<Int32> Add512(Int32 v1val, Int32 v2val)
				{
          Vector512<Int32> v1 = Vector512.Create(v1val);
          Vector512<Int32> v2 = Vector512.Create(v2val);
          Vector512<Int32> v3 = Avx512.Add(v1, v2);
          return v3;
			  }

        [MethodImpl(MethodImplOptions.NoInlining)]
				static Vector512<float> Add512F(float v1val, float v2val)
				{
          Vector512<float> v1 = Vector512.Create(v1val);
          Vector512<float> v2 = Vector512.Create(v2val);
          Vector512<float> v3 = Avx512.Add(v1, v2);
          return v3;
			  }

				[MethodImpl(MethodImplOptions.NoInlining)]
				static Vector512<float> Add512Wrap(Vector512<float> v1, Vector512<float> v2)
				{
          Vector512<float> v3 = Avx512.Add(v1, v2);
          return v3;
			  }

				[MethodImpl(MethodImplOptions.NoInlining)]
				static Vector512<float> Add512FRound(Vector512<float> v1, Vector512<float> v2)
				{
          Vector512<float> v3 = Avx512.AddRound(v1, v2, 10);
          return v3;
			  }

        static void Main(string[] args)
        {
          Int32 v1val = Int32.Parse(args[0]);
          Int32 v2val = Int32.Parse(args[1]);

					/*
          Vector128<Int32> v1 = Add128(v1val, v2val);
          Vector128<float> v2 = Add128F((float)v1val, (float)v2val);

          Vector512<Int32> v3 = Add512(v1val, v2val);
          Vector512<float> v4 = Add512F((float)v1val, (float)v2val);

          Vector512<float> v5 = Vector512.Create((float) v1val);
          Vector512<float> v6 = Vector512.Create((float) v2val);
          Vector512<float> v7 = Add512Wrap(v5, v6);
					*/

          Vector512<float> v5 = Vector512.Create((float) v1val);
          Vector512<float> v6 = Vector512.Create((float) v2val);
          Vector512<float> v7 = Add512FRound(v5, v6);

        }
    }
}
