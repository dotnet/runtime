#!/bin/bash

export COMPlus_JitTieredCompilation=0
export COMPlus_JitDumpTier0=1
export COMPlus_JitDisasm="Add256"
export COMPlus_JitDiffableDsasm=1

/home/acanino/Projects/dotnet/runtime/artifacts/bin/coreclr/Linux.x64.Checked/corerun bin/Release/net6.0/linux-x64/publish/pf-v512.dll > coreclr.dasm
