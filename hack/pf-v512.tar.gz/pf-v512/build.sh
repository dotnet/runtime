#!/bin/bash

/home/acanino/Projects/dotnet/runtime-nightly/dotnet publish -c Release
